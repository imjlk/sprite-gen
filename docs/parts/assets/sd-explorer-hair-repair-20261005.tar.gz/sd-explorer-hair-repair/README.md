# SD Explorer: fitted short-hair revision, 2026-10-05

This is a self-contained local runtime library for the sprite-gen parts-system
branch. It changes only the short hair drawing and that part binding; body,
other parts and three shared native motion clips remain unchanged.

From the sprite-gen source checkout, run:

```sh
.venv/bin/python -m sprite_gen.cli parts-play --assembly /path/to/sd-explorer-hair-repair/library/assembly.json --port 8766
```

The former 56x49 short hair failed size/placement checks in 288 native samples
and introduced enclosed head gaps in 240. The redrawn 44x38 cap passes the
explicit authored checks across all 288. Source pixels, attachment interpolation,
clock and other layers stay intact. There is no runtime scale or appearance bake.

`fit-repair.json` contains both measured attempts. `fit-rules.json` declares the
manual SD reference anchor, maximum size/bounds, scalp coverage, face/ear keepout
and head gap region. Those annotations apply only to this body and short style.
Existing holes in the body are recorded separately from holes introduced by a part.

`generation-prompts.json` records the built-in imagegen edit. Reference images,
raw generated output, one-time import calibration, corrected layer, binding and
recipe code are included. The recipe consumes the supplied generator output;
it does not automatically call an image service. Its adapter supports bounded
correction/recheck and the generic module allows at most three retries, stops
repeated pixels/placement, and leaves failed candidates inactive.

Rebuild the revision using the previous M1 equipment checkpoint (from its
published package or local working assets) and the included raw image:

```sh
.venv/bin/python scripts/dev/sd_explorer_hair_repair.py --source /path/to/previous-m1 --base /path/to/new-revision --raw-hair /path/to/sd-explorer-hair-repair/raw-hair-attempt-1.png
```

All 221 parts regressions pass. Visual appearance acceptance and contact/style
approval remain unverified; the geometric check does not grant an art release.
