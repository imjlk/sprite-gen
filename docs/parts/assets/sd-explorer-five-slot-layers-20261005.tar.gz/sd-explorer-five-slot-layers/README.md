# SD Explorer: five independent customization layers

This checkpoint keeps one intact body frame and draws the selected eye, hair,
upper clothing, lower clothing and footwear pictures above it. There are three
shared body motions, ten designs and 32 appearances. The 96 state cases are
validation combinations, not 96 stored appearance clips.

From the repository, run the extracted workspace with:

```sh
.venv/bin/python -m sprite_gen.cli parts-play --assembly /path/to/sd-explorer-five-slot-layers/library/assembly.json --port 8766
```

The artifact has no dependency on the author's original assets directory.
Part imports, raw generated art, body videos, source frames, source pose guides,
prompts, asset calibration values and sample-to-pose choices are included.
The lower and footwear designs each share 16 authored pose pictures across all
appearances. Playback selects a picture and translates it; the body is never
split or replaced. Upper drawings are sized once at import, then held unchanged.
Short hair retains its [2, -1] alignment correction on the 128 × 128 grid.

`validation.json` records 9,216 body/sample checks and 32 distinct appearances
per state. Empty and live swaps preserve the body and common clock. The
`32-appearances-review.png` shows sample zero only. Browser screenshots and
`browser-validation.json` cover representative live scenes, not every pose.

Art acceptance and release approval remain false. Pose transitions, arm/clothing
occlusion and headwear/gloves/back equipment coverage still need visual work.
The two expression choices change eyes and brows; the body's small mouth stays.

For another technical check using the saved data:

```sh
.venv/bin/python scripts/dev/sd_explorer_five_slot_layers.py --base /path/to/sd-explorer-five-slot-layers --check
```

This check writes comparison and validation files beside the immutable library;
it does not generate a motion or bake appearance clips.
