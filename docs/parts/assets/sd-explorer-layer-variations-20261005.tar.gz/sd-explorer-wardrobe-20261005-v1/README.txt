SD whole-body layer wardrobe checkpoint (2026-10-05)

Play the frozen workspace with the repository CLI:
  .venv/bin/python -m sprite_gen.cli parts-play --assembly <extracted>/sd-explorer-wardrobe-20261005-v1/library/assembly.json --port 8766

Current runtime art: eyes, hair and upper clothing, two real designs each.
The base body, three shared motion clips and frame timing are unchanged.
A/B selections produce eight appearances; empty options extend inspection to
27 layer sets, three states and 7,776 sample evaluations. No appearance clip
was baked. Artwork is a review candidate; the full five-slot goal is unfinished.

Rebuild new designs from the original simple-layer source package using:
  .venv/bin/python scripts/dev/sd_explorer_layer_variations.py --source <simple-layer-base> --base <new-wardrobe-base>
The new base must contain raw-art/ and variants-art.json from this package.
Verification of this frozen workspace:
  .venv/bin/python scripts/dev/sd_explorer_layer_variations.py --base <extracted>/sd-explorer-wardrobe-20261005-v1 --check

Generation prompts and raw outputs are captured. pose-guides/ and pose-art/
contain 16-pose lower-clothing/boot candidates, not active runtime bindings.
Those candidates require fitting, complete sample coverage and both designs.
The original oversized drafts are kept as provenance, not production assets.
