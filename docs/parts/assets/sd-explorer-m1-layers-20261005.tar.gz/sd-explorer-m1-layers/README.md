# SD Explorer M1 runtime wardrobe

Run the extracted, self-contained library from the repository:

```sh
.venv/bin/python -m sprite_gen.cli parts-play --assembly /path/to/sd-explorer-m1-layers/library/assembly.json --port 8766
```

The five main groups each have two designs. The equipment section adds safari
hat, leather gloves and backpack, each with None/on. Thus there are 32 base
appearances and 256 selections including equipment, all using the same three
real Grok body motions. No appearance clip library is baked.

The entire source body remains one immutable raster at (0,0). Eyes/hair/upper
clothing are held pictures; lower clothing and footwear share sixteen pose
drawings per design. Gloves use sixteen calibrated pose references and
compatible drawings with bounded palm estimates. The hat is a head layer and
the bag is drawn behind the body. Foreground skin coverage limits only the upper
clothing layer, preserving arms in front of it. Turning upper clothing off also
removes its occlusion matte. No body splitting, replacement or runtime warp is
used. Only the original root/head/torso position references are required.

`validation.json` covers all 73,728 scene samples, all 112 selection pairs and
24 selected risk-triple combinations. Raster checks at sample zero and focused
visual reviews are separate scopes. The source art, generation prompts,
coordinate calibration, full motion frames, original videos and bindings are
included. Archive restoration is checked independently.

`illustrative-game-travel.json` authors 0/24/48 px/s idle/walk/run movement for a
single cycle. The QA snapshot contains exact translated world frames and contact
sheets. It declares no foot stances, infers no contacts and grants no approval.

Art/release approval remains false. Palm estimates are not anatomical left/right
tracking, pose matching is approximate, and full contact/style acceptance is a
separate review. This is a working implementation/demo artifact.

Recheck the runtime matrix with:

```sh
.venv/bin/python scripts/dev/sd_explorer_equipment_layers.py --base /path/to/sd-explorer-m1-layers --check
```
